//
//  main.cpp
//  KamronAzimov
//
//  Created by Kamron on 13/03/22.
//
#include "Student.hpp"
#include "Person.hpp"

int main()
{
    Person person1("Rock", "Roll", "11011", 21);
    person1.display();
    
    Student student1("Rock", "Roll", "11011", 21, "21SE021", 99.9);
    student1.display();
    
    return 0;
};
