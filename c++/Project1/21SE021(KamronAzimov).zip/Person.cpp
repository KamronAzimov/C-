//
//  Person.cpp
//  KamronAzimov
//
//  Created by Kamron on 13/03/22.
//

#include "Person.hpp"
 
//using namespace std;

Person::Person(string fn, string ln, string id, int a)
{
    FirstName = fn;
    LastName = ln;
    PassportId = id;
    Age = a;
}

void Person::setFirstName(string fn)
{FirstName = fn; }

void Person::setLastName(string ln)
{LastName = ln; }

void Person::setPassportId(string id)
{PassportId = id; }

void Person::setAge(int a)
{Age = a; }

string Person::getFirstName()
{return FirstName; }

string Person::getLastName()
{return LastName;}

string Person::getPassportId()
{return  PassportId;}

int Person::getAge()
{return  Age;}

void Person::display()
{
    cout << "First Name is -> " << getFirstName()
    <<endl << "Last Name is -> " << getLastName()
    <<endl << "Passport Id is -> " <<getPassportId()
    <<endl << "Age is -> " << getAge() << endl;
};
