//
//  Student.cpp
//  KamronAzimov
//
//  Created by Kamron on 13/03/22.
//

#include "Student.hpp"


Student::Student(string fn, string ln, string id, int a, string sid, float g):Person(fn, ln, id, a)
{
    StudentId = sid;
    Grade = g;
}

void Student::setStudentId(string sid)
{this-> StudentId = sid; }

void Student::setGrade(float g)
{this-> Grade = g; }

string Student::getStudentId()
{return  StudentId; }

float Student::getGrade()
{return  Grade; }

void Student::display()
{    Person::display();
    cout << "Student id is -> " << getStudentId()
    << endl << "Grade is -> " << getGrade() << endl;
    
}
