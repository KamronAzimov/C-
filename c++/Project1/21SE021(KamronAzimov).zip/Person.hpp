//
//  Person.hpp
//  KamronAzimov
//
//  Created by Kamron on 13/03/22.
//

#ifndef Person_hpp
#define Person_hpp

#include <iostream> // import iostream library
#include <string> // import string library

using namespace std;

//start class Person
class Person
{
private:
    //Data member
    string FirstName;
    string LastName;
    string PassportId;
    int Age;
//start public data
public:
    Person(string fn, string ln, string id, int a);
    
    void setFirstName(string fn);
    void setLastName(string ln);
    void setPassportId(string id);
    void setAge(int a);
    
    string getFirstName();
    string getLastName();
    string getPassportId();
    int getAge();
    
    //command to display
    void display();
    
};

#endif /* Person_hpp */
