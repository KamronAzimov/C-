//
//  Student.hpp
//  KamronAzimov
//
//  Created by Kamron on 13/03/22.
//

#ifndef Student_hpp
#define Student_hpp

#include "Person.hpp"

#include <string>

using namespace std;

//start class Student with Person class
class Student:public Person
{
private:
    string StudentId;
    float Grade;
    
public:
    Student(string fn, string ln, string id, int a, string sid, float g);
    
    void setStudentId(string sid);
    void setGrade(float g);
    
    string getStudentId();
    float getGrade();
    
    void display();
    
};

#endif /* Student_hpp */
