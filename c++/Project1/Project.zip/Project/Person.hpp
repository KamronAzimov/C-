//
//  Person.hpp
//  Project
//
//  Created by Kamron on 28/03/22.
//

#ifndef Person_hpp
#define Person_hpp

#include <iostream>
#include <string>

using namespace std;

class Person
{
    //Data
private:
    string FirstName;
    string LastName;
public:
    //setters
    Person(string FirstName, string LastName);
    
    void setFirstName(string FirstName);
    void setLastName(string LastName);
    
    string getFirstName();
    string getLastName();
    
    void display();
};

//
#endif /* Person_hpp */

