//
//  Location.hpp
//  Project
//
//  Created by Kamron on 28/03/22.
//

#ifndef Location_hpp
#define Location_hpp

#include "Person.hpp"

// #include <iostream>
// #include <string>

// using namespace std;

class Location:public Person
{
    //data
private:
    int Home = 0.0;
    int Home1 = 0.0;
    float  Home2 = 0.0;
    double Home3 = 0.0;
    
public:
    Location(int Home, int Home1, float Home2, double Home3, string FirstName, string LastName);
    //setters
    void setHome(int Home);
    void setHome1(int Home1);
    void setHome2(float Home2);
    void setHome3(double Home3);
    
    int getHome();
    int getHome1();
    float getHome2();
    double getHome3();
    
    void display();
};

#endif /* Location_hpp */
