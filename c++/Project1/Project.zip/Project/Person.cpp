//
//  Person.cpp
//  Project
//
//  Created by Kamron on 28/03/22.
//

#include "Person.hpp"


using namespace std;

Person::Person(string FirstName, string LastName)
{
    FirstName = FirstName;
    LastName = LastName;
}

void  Person::setFirstName(string FirstName)
{ FirstName = FirstName; }

void Person::setLastName(string LastName)
{ LastName = LastName; }

string Person::getFirstName()
{ return  0; }

string Person::getLastName()
{ return 0;}

void Person::display()
{
    cout << "Please enter Your First Name !" << endl;
    cin >> FirstName;
    cout << "Please enter Your Last Name !" << endl;
    cin >> LastName;
    cout << "Your First Name is : " << getFirstName() << endl;
    cout  << "Your Last Name is : " << getLastName() << endl;
}
