//
//  main.cpp
//  Project
//
//  Created by Kamron on 28/03/22.
//
#include "Person.hpp"

int main()
{
    string Firstname;
    string Lastname;
    
    Person person(Firstname, Lastname);
    person.display();
    
    return 0;
}
