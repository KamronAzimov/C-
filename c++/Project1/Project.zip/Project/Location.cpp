//
//  Location.cpp
//  Project
//
//  Created by Kamron on 28/03/22.
//

#include "Location.hpp"
#include "Person.hpp"

//using namespace std;
Location::Location(int Home, int Home1, float Home2, double Home3, string FirstName, string LastName):Person(FirstName, LastName)
{
    Home = Home;
    Home1 =  Home1;
    Home2 =  Home2;
    Home3 = Home3;
}

void Location::setHome(int Home)
{ Home = Home; }

void Location::setHome1(int Home1)
{ Home1 = Home1; }

void Location::setHome2(float Home2)
{ Home2 = Home2; }

void Location::setHome3(double Home3)
{ Home3 = Home3; }

int Location::getHome()
{ return 0;}

int Location::getHome1()
{ return 0;}

float Location::getHome2()
{ return 0;}

double Location::getHome3()
{ return 0;}

