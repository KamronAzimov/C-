#ifndef Human_h
#define Human_h

#include <iostream>
#include <string>

using namespace std;

class Human
{
private:
    int left_hand, right_hand;
    string first_name, last_name, id_number;

public:
    Human();
    void setLeftHand(int);
    void setRightHand(int);
    void setFirstName(first_name : string);
    void setLastName(last_name : string);
    void setIdNumber(id_number : string);
    int getLeftHand() const;
    int getRightHand() const;
    string getFirstName() const;
    string getLastName() const;
    string getIdNumber() const;
};

#endif // end of human.h