#include "human.h"
using namespace std;

int main()
{
    Human human(1, 1, "Hello", "World", 11);

    human.display();
    return 0;

}