#include "human.h"

Human::human()
{
    left_hand = right_hand = 1.0;
}

void human::setLeftHand(int _left)
{
    left_hand = _left;
}

void human::setRightHand(int _right)
{
    right_hand = _right;
}

void human::setFirstName(string _first)
{
    first_name = _first;
}

void human::setLastName(string _last)
{
    last_name = _last;
}

void human::setIdNumber(string _id)
{
    id_number = _id;
}

int human::getLeftHand() const
{
    return left_hand;
}
int human::getRightHand() const
{
    return right_hand;
}
string human::getFirstName() const
{
    return first_name;
}
string human::getLastName() const
{
    return last_name;
}
string human::getIdNumber() const
{
    return id_number;
}

void human.display()
{
    cout << "Left hand: " << get_left() << endl;
    cout << "Right hand: " << get_right() << endl;
    cout << "First Name: " << get_first() << endl;
    cout << "Last Name: " << get_last() << endl;
    cout << "Id number: " << get_id() << endl;
}
